<?php
/*
 * Plugin Name: PHPFramework
 * Plugin URI: https://phpframework.pt
 * Description: Allows calling theme parts independent
 * Author: Joao Pinto
 * Author URI: http://phpframework.pt/
 * Version: 1
 */

add_filter("option_template", "my_get_template");
add_filter("option_stylesheet", "my_get_template");
add_filter("option_current_theme", "my_get_template");

function my_get_template($template) {
	global $phpframework_template;
	
	return $phpframework_template ? $phpframework_template : $template;
}

