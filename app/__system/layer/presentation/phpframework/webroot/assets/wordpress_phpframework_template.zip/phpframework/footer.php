<?php
wp_footer(); //wp_footer is in wordpress/wp-includes/general-template.php
?>
