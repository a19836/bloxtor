<?php 
wp_head(); //wp_head is in wordpress/wp-includes/general-template.php
wp_body_open(); //wp_body_open is in wordpress/wp-includes/general-template.php
 ?>
