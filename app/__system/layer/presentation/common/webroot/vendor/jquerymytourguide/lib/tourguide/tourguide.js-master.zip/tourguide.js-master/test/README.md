### Steps to run unit-tests for tourguide.js
1. Clone this Repo "tourguide.js", 
2. Navigate to ./test folder
3. Make sure you have NodeJs(v8 or higher) installed
4. run "npm install"
5. run "npm test" 