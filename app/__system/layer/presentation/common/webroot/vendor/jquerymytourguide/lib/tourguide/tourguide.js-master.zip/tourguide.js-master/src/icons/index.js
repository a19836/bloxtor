const Icons = `<svg id="GuidedTourIconSet" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="display: none;">
<symbol id="tour-icon-close" viewBox="0 0 20 20"><g fill="none" stroke="currentColor" stroke-width="2"><path d="M16,16 L4,4"></path><path d="M16,4 L4,16"></path></g></symbol>
<symbol id="tour-icon-next" viewBox="0 0 20 20"><polyline points="7 4 13 10 7 16" fill="none" stroke="currentColor" stroke-width="1"></polyline></symbol>
<symbol id="tour-icon-prev" viewBox="0 0 20 20"><polyline points="12 4 6 10 12 16" fill="none" stroke="currentColor" stroke-width="1"></polyline></symbol>
<symbol id="tour-icon-complete" viewBox="0 0 20 20"><polyline points="4,10 8,15 17,4" fill="none" stroke="currentColor" stroke-width="1"></polyline></symbol>
</svg>`;
export default Icons;